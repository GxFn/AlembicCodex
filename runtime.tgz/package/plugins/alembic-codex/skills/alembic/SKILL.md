---
name: alembic
description: Use Alembic from Codex. Start here for status, initialization, project priming, Guard checks, Codex host-agent bootstrap/rescan workflows, explicit internal AI jobs, Dashboard handoff, and permission boundaries.
---

# Alembic Codex Workflow

Use this skill when the user asks Codex to work with project conventions, local knowledge, Guard checks, Codex host-agent bootstrap/rescan workflows, explicit internal AI jobs, or Alembic itself.

## First Move

Call `alembic_codex_status` before assuming Alembic is initialized. This status check is local and must not start the daemon.

If status reports runtime or environment problems, call `alembic_codex_diagnostics` and surface the suggested fix. Diagnostics also runs without starting the daemon.

If status or diagnostics says the project root is unresolved or points inside the Codex plugin cache, pass the current workspace directory as the `projectRoot` argument on subsequent Alembic tool calls. `projectRoot` must be an absolute path; without it, Alembic project workflows cannot run.

If the workspace is not initialized and the user wants Alembic knowledge for this project, call `alembic_codex_init`. The default profile is Ghost mode, so Alembic data is stored in the external workspace data root and Codex does not write IDE configuration into the project.

## Daily Coding Flow

For non-trivial coding tasks:

1. Call `alembic_task` with `operation: "prime"` and include the user's task.
2. Immediately after the prime tool result, make a developer-visible receipt shout in your own words from `primeKnowledgeMaterial`: briefly and actively shout as Codex or "I" which Recipe constraints, Guard rules, patterns, or judgment basis you accepted, or say you received no usable project knowledge because the result was empty or degraded. This must be the next visible response before any search, code reading, edit, Guard check, or final summary. Keep evidence refs in the payload for later verification or user-requested citations; do not dump paths or line numbers by default. Do not make "Alembic prime", prime, or any tool/process the speaker or subject of the visible receipt.
3. Use `alembic_search`, `alembic_knowledge`, or `alembic_structure` when more project context is needed.
4. Make code changes according to approved Recipes and project evidence.
5. Call `alembic_guard` after meaningful edits, especially before summarizing completion.
6. If a reusable convention appears, submit a candidate with `alembic_submit_knowledge`; do not write Recipe files directly.

Prime and search can include `searchMeta.residentSearch` / `residentVector` diagnostics. When a local Alembic resident service is ready, semantic/vector recall is requested there and the metadata shows the resident route, Codex requested mode, daemon resident request mode, actual mode, vector usage, and fallback reason. When the resident service is unavailable, continue with Plugin baseline knowledge search and treat `residentVector.available=false` as an expected enhancement boundary, not as a Plugin embedding failure.

## Long-Running Work

Use `alembic_bootstrap` for default Codex host-agent cold start and `alembic_rescan` for host-agent refresh. Codex reads the Mission Briefing, analyzes the project, submits knowledge, and completes dimensions; this path does not require an Alembic AI Provider.

Use `alembic_codex_bootstrap` and `alembic_codex_rescan` only when the user explicitly wants Alembic daemon jobs. Any provider credentials or model choices belong to the Alembic resident service, not this Codex plugin; these tools only start/connect to the daemon, enqueue work, and return a recoverable job id.

Use `alembic_codex_job` to check explicit internal AI job status later. Job lookup is local and should not start the daemon.

Use `alembic_codex_dashboard` when the user needs review, candidates, or progress visualization and a local Alembic Dashboard daemon is already available for the selected project. Return its URL instead of opening a browser yourself; if the tool reports missing Dashboard handoff capability, surface that next step instead of inventing an embedded Dashboard URL.

## Project Skill Delivery

Use `alembic_project_skill` for Project Skill receipt, export, and Codex runtime visibility. This is the Codex-facing replacement for using `alembic_skill` as the runtime delivery surface.

- `list` shows Alembic project skill storage, Plugin delivery receipts, and Codex runtime exports under the current project's `.agents/skills` root.
- `load` prefers `.agents/skills/<name>/SKILL.md` and falls back to legacy Alembic storage when no runtime export exists.
- `create` and `update` keep writing Alembic project skill storage, then return a Plugin route `ProjectSkillDeliveryReceipt`.
- `export` consumes a `ProjectSkillDeliveryReceipt` and uses symlink-first delivery into `.agents/skills` only after project-scoped authorization.

Set `authorizeProjectSkillExport: true` only when the user has approved making that Project Skill visible in this project. A blocked response with `authorizationStatus: "pending"` means the receipt is valid but Codex has not been authorized to write `.agents/skills`.

If `conflictStatus` is `different-existing`, do not overwrite it by guessing. The target already exists and is not managed by the matching Alembic receipt, so ask for user direction or report the conflict. Managed exports write `.alembic-managed.json`; compatible managed or same-source symlink exports can be refreshed.

`alembic_skill` remains for legacy Alembic storage compatibility. Prefer `alembic_project_skill` whenever the user needs runtime-visible Project Skills, receipt evidence, authorization state, conflict state, or export status.

## Permission Boundary

Default Codex mode is agent tier. It may search knowledge, prime tasks, run Guard, use host-agent bootstrap/rescan, and submit candidates. Explicit daemon jobs may require Alembic resident-service configuration, but the Codex plugin does not configure third-party AI providers or store API keys.

Do not publish, deprecate, delete, or directly edit Recipes from the default tier. Admin tools only appear when both `ALEMBIC_MCP_TIER=admin` and `ALEMBIC_CODEX_ENABLE_ADMIN=1` are set.

Do not edit host configuration files, `AGENTS.md`, or project Alembic data unless the user explicitly asks for a standard, project-written setup.

## Cleanup

Plugin uninstall never removes user data. Use `alembic_codex_cleanup` for explicit cleanup. The default call is a dry run; `confirm=true` only removes daemon runtime state, logs, locks, and job files.

## Related Skills

- `alembic-recipes`: Recipe lookup and application.
- `alembic-create`: Candidate submission rules.
- `alembic-guard`: Compliance checks.
- `alembic-structure`: Project targets, files, metadata, graph, and call context.
